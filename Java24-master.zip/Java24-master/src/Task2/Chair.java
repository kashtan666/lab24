package Task2;

public interface Chair {
}
