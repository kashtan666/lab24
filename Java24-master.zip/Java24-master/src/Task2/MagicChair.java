package Task2;

public class MagicChair implements Chair{

    public void doMagic(){
        System.out.println("великобритания утонула");
    }
}
