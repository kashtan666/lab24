package Task1;

public interface ComplexAbstractFactory {
    public Complex createComplex();
    public Complex CreateComplex(int real, int image);
}
