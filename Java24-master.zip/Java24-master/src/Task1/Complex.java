package Task1;

public class Complex {
    private int real;
    private int image;
    Complex(int real, int image){
        this.real = real;
        this.image = image;
    }
    Complex(){
        this.real = 0;
        this.image = 0;
    }
}
